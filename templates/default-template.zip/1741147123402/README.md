# This is a title

## This is a heading

### This is a subheading

#### This is a sub-subheading

##### This is a sub-sub-subheading

###### This is just insane

*This is how you italicize text*

**This is how you bold text**

1. This 
2. is 
3. how
4. you 
5. make
6. a 
7. numbered
8. list

* This is how you make a bullet list
+ And this
- And this too

> "This is how you make a quote block" - NTIHKH, 2025

`console.log('This is how you make a code span');`

```js
function runMe() {
	console.log('This is how you make a code block');
}
```

[This is how you make a link](https://example.com "With titles!")

[This is how you reference a later link][1]

[1]: https://thisiswhereyoudefinethereferencelink.com "With titles!"

![This is how you define images](images/pic.jpg)

***

You can also...

---

split up text...

___

using horizontal breaks!